# Happy Dussehra – Basudev Sahoo, Damarpur

3D Dussehra website (English / हिन्दी / ଓଡ଼ିଆ) with Maa Durga, festive offers and Raavan Dahan.

## Folder structure
```
dussehra-website/
├── index.html          # page structure
├── css/style.css       # all styling and animations
├── js/
│   ├── translations.js # English, Hindi, Odia text
│   ├── offers.js       # offers: prices, discount %, coupon codes
│   ├── images.js       # image paths
│   └── main.js         # language switch, 3D tilt, fireworks, Raavan burn
└── images/
    ├── durga.jpg
    └── raavan.jpg
```

## Run
Just open `index.html` in a browser (no build step needed).

## Deploy (Vercel)
Upload this whole folder as a static site, or run `vercel` inside it.

## Quick edits
- Prices / offers: `js/offers.js`
- Text or language changes: `js/translations.js`
- Images: replace the files in `images/` (keep the same names)
- Colours: `:root` variables at the top of `css/style.css`
