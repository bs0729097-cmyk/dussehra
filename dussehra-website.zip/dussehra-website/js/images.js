// d = Maa Durga image, r = Raavan image
const IMG={d:'images/durga.jpg',r:'images/raavan.jpg'};
