document.querySelectorAll('[data-img]').forEach(i=>i.src=IMG[i.dataset.img]);
const wa=t=>'https://wa.me/?text='+encodeURIComponent(t);
let lg='en',cur=null;
const fm=n=>'₹'+n.toLocaleString('en-IN');
function apply(l){lg=l;try{localStorage.setItem('lg',l)}catch(e){}
 document.documentElement.lang=l;
 document.querySelectorAll('[data-i]').forEach(e=>e.textContent=L[l][e.dataset.i]);
 document.querySelectorAll('.lang button').forEach(b=>b.classList.toggle('on',b.dataset.l===l));
 document.getElementById('cards').innerHTML=O.map((x,i)=>`<div class="card tilt" onclick="show(${i})"><div class="pct">${x.p}% OFF</div><div class="pic" style="background:radial-gradient(circle at 30% 30%,${x.c.split(',')[0]},${x.c.split(',')[1]})">${x.e}</div><h3>${x.t[l][0]}</h3><p>${x.t[l][1]}</p><div class="price">${fm(x.n)}<s>${fm(x.o)}</s></div><button class="btn">${L[l].open}</button></div>`).join('');
 document.querySelectorAll('.wal').forEach(a=>a.href=wa(L[l].shm+' '+location.href));bindTilt();if(cur!==null)show(cur);}
function show(i){cur=i;const x=O[i],t=L[lg],d=new Date().toLocaleDateString();
 document.getElementById('letter').innerHTML=`<div class="pic" style="background:radial-gradient(circle at 30% 30%,${x.c.split(',')[0]},${x.c.split(',')[1]})">${x.e}</div><h4>🪔 ${t.lt} 🪔</h4><div style="text-align:center;font-size:13px">Dussehra 2026 • ${t.date}: ${d}</div><p><b>${t.dear}</b></p><p>${t.body}</p><table><tr><td>${t.of}</td><td>${x.t[lg][0]}</td></tr><tr><td>${t.pr}</td><td>${fm(x.n)} <s style="opacity:.6">${fm(x.o)}</s></td></tr><tr><td>${t.sv}</td><td>${fm(x.o-x.n)} (${x.p}%)</td></tr><tr><td>${t.va}</td><td>${t.vd}</td></tr><tr><td>${t.cd}</td><td>${x.code}</td></tr></table><div class="sign">${t.sg}<br><b>Basudev Sahoo, Damarpur</b></div><a class="btn wa" target="_blank" rel="noopener" href="${wa(`🪔 ${x.t[lg][0]} — ${fm(x.n)} (${x.p}% OFF)\n${t.cd}: ${x.code}\n${t.shm} ${location.href}`)}">${t.sh}</a><button class="btn" onclick="closeM()">${t.cl}</button>`;
 document.getElementById('modal').classList.add('on');burst(innerWidth/2,innerHeight/3)}
function closeM(){cur=null;document.getElementById('modal').classList.remove('on')}
document.getElementById('modal').onclick=e=>{if(e.target.id==='modal')closeM()};
document.querySelectorAll('.lang button').forEach(b=>b.onclick=()=>apply(b.dataset.l));
function bindTilt(){document.querySelectorAll('.tilt').forEach(el=>{if(el.dataset.b)return;el.dataset.b=1;const host=el.id==='ht'?document.getElementById('home'):el;
 const mv=e=>{const r=el.getBoundingClientRect(),x=((e.clientX-r.left)/r.width-.5),y=((e.clientY-r.top)/r.height-.5);
  el.style.transform=`perspective(900px) rotateY(${x*22}deg) rotateX(${-y*22}deg)`;if(el.id==='ht'){const s=document.getElementById('dsvg').style;s.setProperty('--px',x*2);s.setProperty('--py',y*2)}};
 const rs=()=>{el.style.transform='';};
 host.addEventListener('pointermove',mv);host.addEventListener('pointerleave',rs);host.addEventListener('pointerup',e=>{if(e.pointerType!=='mouse')rs()})})}
const rv=document.getElementById('rav');
document.getElementById('burn').onclick=()=>{rv.classList.remove('burning');void rv.getBoundingClientRect();rv.classList.add('burning');for(let i=0;i<8;i++)setTimeout(()=>burst(innerWidth*(.15+Math.random()*.7),innerHeight*(.15+Math.random()*.4)),i*450)};
/* particles */
const cv=document.getElementById('fx'),cx=cv.getContext('2d');let P=[];
function sz(){cv.width=innerWidth;cv.height=innerHeight}sz();addEventListener('resize',sz);
function burst(x,y){const c=`hsl(${Math.random()*60+10},100%,60%)`;for(let i=0;i<46;i++){const a=Math.random()*6.28,s=Math.random()*5+1;P.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,l:60+Math.random()*30,c,g:.06})}}
for(let i=0;i<40;i++)P.push({x:Math.random()*innerWidth,y:Math.random()*innerHeight,vx:(Math.random()-.5)*.4,vy:-Math.random()*.8-.2,l:1e9,c:'#ffb347',g:0,e:1});
(function loop(){cx.clearRect(0,0,cv.width,cv.height);
 P=P.filter(p=>{p.x+=p.vx;p.y+=p.vy;p.vy+=p.g;p.l--;if(p.e&&p.y<-10){p.y=cv.height+10;p.x=Math.random()*cv.width}
  cx.globalAlpha=p.e?.5:Math.min(1,p.l/30);cx.fillStyle=p.c;cx.beginPath();cx.arc(p.x,p.y,p.e?1.8:2.2,0,6.28);cx.fill();return p.l>0});
 requestAnimationFrame(loop)})();
let sv='en';try{sv=localStorage.getItem('lg')||'en'}catch(e){}
apply(L[sv]?sv:'en');
